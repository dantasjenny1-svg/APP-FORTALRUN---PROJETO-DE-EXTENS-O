# FORTALRUN
Protótipo acadêmico multiplataforma para Android e iOS.

## Tecnologias
- Aplicativo: React Native + Expo + TypeScript.
- API: Python + FastAPI.
- Recomendação: algoritmo multicritério simples e explicável.
- Dados: JSON demonstrativo (não são dados verificados em tempo real).

## Executar a API
Python 3.10+:
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r ../requirements.txt
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```
Documentação: http://localhost:8000/docs

## Executar o app
Instale Node.js LTS e Expo Go:
```bash
cd frontend
npm install
npx expo start
```
Leia o QR Code no Expo Go. Em celular físico, edite `frontend/config.ts` e use o IP local do computador no lugar de `localhost`.
Para compilar nativamente: `npx expo run:android` ou `npx expo run:ios` (iOS local requer macOS/Xcode; EAS Build é alternativa).

## Funcionalidades demonstradas
- Tela inicial FORTALRUN.
- Entrada de distância e horário.
- Consulta à API e classificação das rotas.
- Exibição de pontuação e critérios.

## Limitações
MVP acadêmico. As rotas e notas são dados fictícios/demonstrativos. Não indicam segurança real nem substituem verificação local. Integrações reais com GPS, mapas, clima, autenticação, notificações e banco persistente ainda precisam ser implementadas e testadas.

## Publicar no GitHub
1. Crie um repositório em https://github.com/new chamado `FORTALRUN`.
2. Extraia este ZIP e envie os arquivos em **Add file > Upload files**, ou use:
```bash
git init
git add .
git commit -m "Versão inicial do FORTALRUN"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/FORTALRUN.git
git push -u origin main
```
3. Copie a URL do repositório para inserir no trabalho acadêmico.
