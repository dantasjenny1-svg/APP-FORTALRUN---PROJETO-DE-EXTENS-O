import json
from pathlib import Path
from fastapi import FastAPI
from pydantic import BaseModel, Field
from recommendation import recommend_routes

app=FastAPI(title="FORTALRUN API", version="0.1.0")
DATA=Path(__file__).parent/"data"/"routes.json"

class Preferences(BaseModel):
    distance_km: float=Field(default=5, gt=0, le=50)
    preferred_time: str="manhã"
    priority: str="equilibrio"

@app.get("/")
def root():
    return {"message":"FORTALRUN API em execução"}

@app.get("/routes")
def routes():
    return json.loads(DATA.read_text(encoding="utf-8"))

@app.post("/recommendations")
def recommendations(preferences: Preferences):
    items=json.loads(DATA.read_text(encoding="utf-8"))
    return {"disclaimer":"Pontuação demonstrativa; não garante segurança.",
            "preferences":preferences.model_dump(),
            "recommendations":recommend_routes(items, preferences.model_dump())}

@app.get("/health")
def health():
    return {"status":"ok"}
