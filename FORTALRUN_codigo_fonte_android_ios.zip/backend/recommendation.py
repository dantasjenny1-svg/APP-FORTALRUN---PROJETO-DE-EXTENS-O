def score_route(route, preferences):
    """Pontuação demonstrativa de compatibilidade entre rota e preferências."""
    target = float(preferences.get("distance_km", 5))
    weights = {"safety": .25, "lighting": .20, "movement": .15,
               "surface": .15, "weather": .10, "support": .05, "distance": .10}
    values = {key: float(route.get(key, 3))/5 for key in
              ["safety", "lighting", "movement", "surface", "weather", "support"]}
    km = float(route.get("distance_km", 0))
    values["distance"] = max(0, 1-abs(km-target)/max(target, 1))
    return round(sum(values[k]*w for k,w in weights.items())*100, 1)

def recommend_routes(routes, preferences):
    result=[]
    for route in routes:
        item=dict(route)
        item["score"]=score_route(route, preferences)
        result.append(item)
    return sorted(result, key=lambda x:x["score"], reverse=True)
