import React, {useState} from "react";
import {SafeAreaView,ScrollView,View,Text,TextInput,Pressable,ActivityIndicator,StyleSheet} from "react-native";
import {StatusBar} from "expo-status-bar";
import {API_URL} from "./config";
type Route={id:number;name:string;neighborhood:string;distance_km:number;score:number;description:string;lighting:number;movement:number;surface:number};
export default function App(){
 const [distance,setDistance]=useState("5"),[time,setTime]=useState("manhã");
 const [routes,setRoutes]=useState<Route[]>([]),[loading,setLoading]=useState(false),[error,setError]=useState("");
 async function search(){
  setLoading(true);setError("");setRoutes([]);
  try{const r=await fetch(`${API_URL}/recommendations`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({distance_km:Number(distance),preferred_time:time,priority:"equilibrio"})});
   if(!r.ok)throw new Error();const data=await r.json();setRoutes(data.recommendations);
  }catch{setError("Não foi possível conectar à API. Verifique o servidor e a configuração de API_URL.");}
  finally{setLoading(false);}
 }
 return <SafeAreaView style={s.safe}><StatusBar style="light"/><ScrollView contentContainerStyle={s.container}>
  <View style={s.hero}><Text style={s.brand}>FORTALRUN</Text><Text style={s.tag}>Sua corrida, com mais informação.</Text><Text style={s.white}>Encontre opções de percurso considerando distância, iluminação, movimentação e condições da rota.</Text></View>
  <View style={s.card}><Text style={s.title}>Planeje sua corrida</Text><Text style={s.label}>Distância desejada (km)</Text><TextInput value={distance} onChangeText={setDistance} keyboardType="numeric" style={s.input}/>
   <Text style={s.label}>Horário pretendido</Text><View style={s.row}>{["manhã","tarde","noite"].map(x=><Pressable key={x} onPress={()=>setTime(x)} style={[s.choice,time===x&&s.active]}><Text>{x}</Text></Pressable>)}</View>
   <Pressable onPress={search} style={s.button}><Text style={s.btnText}>Recomendar rotas</Text></Pressable>
   {loading&&<ActivityIndicator style={{marginTop:14}}/>}{!!error&&<Text style={s.error}>{error}</Text>}
  </View>
  {!!routes.length&&<View style={{marginTop:20}}><Text style={s.title}>Sugestões de percurso</Text>{routes.map(x=><View key={x.id} style={s.route}><Text style={s.routeName}>{x.name} • {x.score.toFixed(0)}/100</Text><Text>{x.neighborhood} • {x.distance_km} km</Text><Text>Iluminação: {x.lighting}/5 • Movimento: {x.movement}/5 • Piso: {x.surface}/5</Text><Text>{x.description}</Text></View>)}<Text style={s.note}>Pontuação demonstrativa; não representa garantia de segurança. Confirme as condições locais.</Text></View>}
  <Text style={s.footer}>Projeto acadêmico • UNIFANOR Wyden</Text>
 </ScrollView></SafeAreaView>;
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:"#F2F6FA"},container:{padding:18,paddingBottom:36},hero:{backgroundColor:"#103D68",borderRadius:22,padding:22,marginBottom:16},brand:{fontSize:30,fontWeight:"900",color:"white"},tag:{fontSize:17,fontWeight:"700",color:"#D8EDFF",marginTop:8},white:{color:"white",lineHeight:21,marginTop:12},card:{backgroundColor:"white",borderRadius:18,padding:18},title:{fontSize:20,fontWeight:"800",color:"#173B5E",marginBottom:14},label:{fontWeight:"700",marginTop:8,marginBottom:7},input:{borderWidth:1,borderColor:"#D6E0E8",borderRadius:10,padding:12,fontSize:16},row:{flexDirection:"row",gap:8},choice:{flex:1,borderWidth:1,borderColor:"#CBD8E3",borderRadius:10,padding:10,alignItems:"center"},active:{backgroundColor:"#DCEEFF",borderColor:"#1263A5"},button:{backgroundColor:"#1263A5",padding:15,borderRadius:12,alignItems:"center",marginTop:18},btnText:{color:"white",fontWeight:"800"},route:{backgroundColor:"white",borderRadius:14,padding:15,marginBottom:10,gap:5},routeName:{fontWeight:"800",color:"#173B5E",fontSize:16},note:{fontSize:11,color:"#667085"},error:{color:"#B42318",marginTop:12},footer:{textAlign:"center",color:"#73808C",fontSize:11,marginTop:24}});
