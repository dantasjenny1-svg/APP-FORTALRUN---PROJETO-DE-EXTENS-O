import streamlit as st
from datetime import datetime

st.set_page_config(
    page_title="FORTALRUN | Corrida inteligente",
    page_icon="🏃",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ------------------------------------------------------------
# FORTALRUN - protótipo acadêmico demonstrativo
# Os dados de rotas e clima abaixo são ilustrativos/fictícios.
# Não representam condições reais ou atuais de Fortaleza.
# ------------------------------------------------------------

COLORS = {
    "navy": "#10243A",
    "blue": "#176B87",
    "cyan": "#39A9B8",
    "orange": "#FF8A3D",
    "light": "#F3F7FA",
    "muted": "#637789",
    "green": "#218C68",
}

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
html, body, [class*="css"] {font-family: 'DM Sans', sans-serif;}
.stApp {background: #F3F7FA;}
.block-container {padding-top: 1.5rem; max-width: 1200px;}
section[data-testid="stSidebar"] {background: #10243A;}
section[data-testid="stSidebar"] * {color: #F4F8FB !important;}
.brand {font-size: 1.65rem; font-weight: 800; letter-spacing: .5px; color: #10243A;}
.brand span {color: #FF8A3D;}
.subtitle {color: #637789; margin-top: -.6rem;}
.hero {background: linear-gradient(120deg,#10243A,#176B87); padding: 28px 30px; border-radius: 20px; color: white; margin-bottom: 18px;}
.hero h1 {color:white; margin:0; font-size:2.1rem;}
.hero p {color:#DCEAF1; margin:.45rem 0 0 0;}
.panel {background:white; padding:20px; border-radius:16px; border:1px solid #E4EBF0; margin-bottom:14px;}
.kpi {background:white; border:1px solid #E4EBF0; padding:17px; border-radius:15px;}
.kpi .num {font-size:1.65rem; font-weight:800; color:#10243A;}
.kpi .lbl {font-size:.85rem; color:#637789;}
.route-title {font-size:1.15rem; font-weight:800; color:#10243A;}
.pill {display:inline-block; background:#E5F4F1; color:#176B61; padding:4px 10px; border-radius:20px; font-size:.78rem; font-weight:700;}
.small {font-size:.82rem; color:#637789;}
.warning {background:#FFF4E9; border-left:4px solid #FF8A3D; padding:12px 15px; border-radius:8px; color:#69401F;}
div.stButton > button {border-radius:10px; font-weight:700; min-height:2.7rem;}
</style>
""", unsafe_allow_html=True)

# Scores from 0 to 10. Illustrative sample data only.
ROTAS = [
    {
        "nome": "Orla da Beira-Mar",
        "regiao": "Meireles / Praia de Iracema",
        "km": 5.0, "seguranca": 7.5, "iluminacao": 9.0,
        "movimentacao": 9.0, "piso": 8.0, "clima": 7.0,
        "apoio": 9.0, "distancia": 9.0,
        "descricao": "Percurso demonstrativo próximo à orla, com referência a pontos de apoio."
    },
    {
        "nome": "Parque do Cocó",
        "regiao": "Cocó",
        "km": 3.0, "seguranca": 7.0, "iluminacao": 6.5,
        "movimentacao": 7.5, "piso": 7.5, "clima": 8.0,
        "apoio": 7.0, "distancia": 8.5,
        "descricao": "Opção demonstrativa em área verde, com distância curta."
    },
    {
        "nome": "Campus do Pici",
        "regiao": "Pici",
        "km": 8.0, "seguranca": 6.5, "iluminacao": 6.0,
        "movimentacao": 6.5, "piso": 7.0, "clima": 8.0,
        "apoio": 6.0, "distancia": 7.0,
        "descricao": "Percurso ilustrativo para demonstrar uma opção de maior distância."
    },
]

CRITERIOS = {
    "Segurança percebida": "seguranca",
    "Iluminação": "iluminacao",
    "Movimentação": "movimentacao",
    "Condição do piso": "piso",
    "Clima": "clima",
    "Pontos de apoio": "apoio",
    "Adequação à distância": "distancia",
}

def pontuar_rota(rota, pesos):
    """Calcula uma média ponderada de critérios em escala demonstrativa de 0 a 10."""
    total_pesos = sum(pesos.values())
    if total_pesos == 0:
        return 0
    soma = 0
    for criterio, peso in pesos.items():
        soma += rota[criterio] * peso
    return soma / total_pesos

def recomendar_rotas(distancia, horario, prioridades):
    pesos = {campo: 1 for campo in CRITERIOS.values()}
    for prioridade in prioridades:
        campo = CRITERIOS[prioridade]
        pesos[campo] += 2

    candidatas = []
    for rota in ROTAS:
        # Distância aproximada: aceita rotas até 2 km acima/abaixo da meta.
        diferenca = abs(rota["km"] - distancia)
        if diferenca <= 2:
            nota = pontuar_rota(rota, pesos)
            # Regra ilustrativa para destacar iluminação em treinos noturnos.
            if horario == "Noite":
                nota = (nota * 0.85) + (rota["iluminacao"] * 0.15)
            candidatas.append((nota, rota))
    candidatas.sort(key=lambda item: item[0], reverse=True)
    return candidatas

def header(titulo, descricao):
    st.markdown(f'<div class="brand">FORTAL<span>RUN</span></div>', unsafe_allow_html=True)
    st.markdown(f'<div class="subtitle">{descricao}</div>', unsafe_allow_html=True)
    st.markdown(f"## {titulo}")

def route_card(nota, rota, pos):
    with st.container(border=True):
        a, b = st.columns([4, 1])
        with a:
            st.markdown(f'<div class="route-title">{pos}. {rota["nome"]}</div>', unsafe_allow_html=True)
            st.caption(f'{rota["regiao"]} • {rota["km"]:.1f} km')
            st.write(rota["descricao"])
            st.markdown(
                f'<span class="pill">Compatibilidade demonstrativa: {nota:.1f}/10</span>',
                unsafe_allow_html=True
            )
        with b:
            st.metric("Pontuação", f"{nota:.1f}/10")
        st.progress(min(nota / 10, 1.0))
        st.caption(
            f'Segurança percebida: {rota["seguranca"]:.1f} • '
            f'Iluminação: {rota["iluminacao"]:.1f} • '
            f'Movimentação: {rota["movimentacao"]:.1f} • '
            f'Piso: {rota["piso"]:.1f}'
        )

if "pagina" not in st.session_state:
    st.session_state.pagina = "Início"
if "resultados" not in st.session_state:
    st.session_state.resultados = None

with st.sidebar:
    st.markdown("# 🏃 FORTALRUN")
    st.caption("Sua corrida começa com uma boa escolha.")
    st.markdown("---")
    paginas = ["Início", "Encontrar rotas", "Condições climáticas", "Meus treinos", "Comunidade"]
    for pagina in paginas:
        if st.button(pagina, key=f"nav_{pagina}", use_container_width=True,
                     type="primary" if st.session_state.pagina == pagina else "secondary"):
            st.session_state.pagina = pagina
            st.rerun()
    st.markdown("---")
    st.caption("Protótipo acadêmico • versão demonstrativa")

pagina = st.session_state.pagina

if pagina == "Início":
    st.markdown("""
    <div class="hero">
      <h1>Olá, corredor(a)! 👋</h1>
      <p>Encontre percursos que combinam com seu treino, suas preferências e o seu momento.</p>
    </div>
    """, unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown('<div class="kpi"><div class="num">46</div><div class="lbl">respostas na pesquisa do projeto</div></div>', unsafe_allow_html=True)
    with c2:
        st.markdown('<div class="kpi"><div class="num">91,3%</div><div class="lbl">intenção positiva de uso (42 de 46)</div></div>', unsafe_allow_html=True)
    with c3:
        st.markdown('<div class="kpi"><div class="num">7</div><div class="lbl">critérios considerados na recomendação</div></div>', unsafe_allow_html=True)
    st.markdown("")
    st.markdown("### O que você quer fazer hoje?")
    c1, c2 = st.columns(2)
    with c1:
        with st.container(border=True):
            st.markdown("### 📍 Encontrar rotas")
            st.write("Informe distância, horário e prioridades para receber sugestões.")
            if st.button("Buscar percursos", use_container_width=True):
                st.session_state.pagina = "Encontrar rotas"
                st.rerun()
    with c2:
        with st.container(border=True):
            st.markdown("### 🌤️ Ver condições climáticas")
            st.write("Consulte um painel climático ilustrativo para a demonstração.")
            if st.button("Ver clima", use_container_width=True):
                st.session_state.pagina = "Condições climáticas"
                st.rerun()
    st.info("A pesquisa do projeto foi respondida por 46 pessoas. Segurança, movimentação, iluminação e qualidade do piso foram os fatores mais citados.")
    st.markdown('<div class="warning"><b>Aviso:</b> este protótipo usa dados fictícios para demonstrar a lógica. Não consulte estas notas para decidir onde correr na vida real.</div>', unsafe_allow_html=True)

elif pagina == "Encontrar rotas":
    header("Encontre sua rota", "Personalize a busca e veja como o algoritmo organiza as opções.")
    with st.container(border=True):
        st.markdown("### 1. Preferências do treino")
        c1, c2 = st.columns(2)
        with c1:
            distancia = st.select_slider("Distância desejada", options=[3, 5, 8, 10], value=5, format_func=lambda x: f"{x} km")
            horario = st.selectbox("Horário da corrida", ["Manhã", "Tarde", "Noite"])
        with c2:
            nivel = st.selectbox("Nível de experiência", ["Iniciante", "Intermediário", "Avançado"])
            prioridades = st.multiselect(
                "O que é mais importante para você?",
                list(CRITERIOS.keys()),
                default=["Segurança percebida", "Iluminação"]
            )
        buscar = st.button("🔎 Buscar rotas recomendadas", type="primary", use_container_width=True)
    if buscar:
        st.session_state.resultados = recomendar_rotas(distancia, horario, prioridades)
        st.session_state.busca_info = (distancia, horario, nivel, prioridades)
    if st.session_state.resultados is not None:
        st.markdown("### 2. Recomendações do sistema")
        if not st.session_state.resultados:
            st.warning("Não encontramos uma rota demonstrativa próxima dessa distância. Tente outra distância.")
        else:
            st.success(f"Foram encontradas {len(st.session_state.resultados)} opções para sua busca.")
            for i, (nota, rota) in enumerate(st.session_state.resultados, start=1):
                route_card(nota, rota, i)
        with st.expander("Como o algoritmo chegou ao resultado?"):
            st.write("O sistema atribui pesos aos critérios escolhidos, calcula uma média ponderada para cada rota e ordena as opções pela pontuação. Para treinos à noite, a iluminação recebe influência adicional.")
            st.code(
                "pontuação = soma(nota_do_critério × peso) / soma dos pesos",
                language="text"
            )
            st.caption("As notas são fictícias e servem exclusivamente para demonstrar variáveis, funções, condicionais, laços e ordenação.")
    st.markdown('<div class="warning"><b>Importante:</b> as rotas, notas e condições são dados de demonstração, não avaliações verificadas dos locais.</div>', unsafe_allow_html=True)

elif pagina == "Condições climáticas":
    header("Condições climáticas", "Painel ilustrativo — sem conexão com serviço meteorológico.")
    st.markdown('<div class="warning"><b>Dados simulados:</b> os valores abaixo não são uma previsão do tempo atual.</div>', unsafe_allow_html=True)
    c1, c2, c3, c4 = st.columns(4)
    for col, val, label in [
        (c1, "28 °C", "Temperatura"),
        (c2, "72%", "Umidade"),
        (c3, "18 km/h", "Vento"),
        (c4, "Moderado", "Índice UV"),
    ]:
        with col:
            st.markdown(f'<div class="kpi"><div class="num">{val}</div><div class="lbl">{label}</div></div>', unsafe_allow_html=True)
    st.markdown("### Condição demonstrativa")
    st.markdown('<div class="panel"><h3>🌤️ Parcialmente nublado</h3><p>Exemplo de informação que poderá ser obtida futuramente por uma API meteorológica.</p><b>Dica de treino:</b> mantenha-se hidratado e adapte a intensidade às condições reais do ambiente.</div>', unsafe_allow_html=True)

elif pagina == "Meus treinos":
    header("Meus treinos", "Área demonstrativa para acompanhamento das atividades.")
    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("Distância da semana", "12,5 km", "+2,0 km")
    with c2:
        st.metric("Tempo total", "1h 18min")
    with c3:
        st.metric("Pace médio", "6:14 min/km")
    st.markdown("### Registrar treino")
    with st.form("treino"):
        col1, col2, col3 = st.columns(3)
        km = col1.number_input("Distância (km)", min_value=0.1, max_value=100.0, value=5.0, step=0.1)
        minutos = col2.number_input("Tempo (minutos)", min_value=1, max_value=600, value=32)
        data = col3.date_input("Data", value=datetime.now().date())
        enviado = st.form_submit_button("Calcular pace")
    if enviado:
        pace = minutos / km
        mm = int(pace)
        ss = int(round((pace - mm) * 60))
        st.success(f"Treino registrado nesta simulação: {km:.1f} km em {minutos} min. Pace calculado: {mm}:{ss:02d} min/km.")
        st.caption("O registro não é salvo em banco de dados; é apenas uma demonstração durante a sessão.")

elif pagina == "Comunidade":
    header("Comunidade RunWorld", "Um espaço proposto para aproximar pessoas que praticam corrida.")
    c1, c2 = st.columns(2)
    with c1:
        with st.container(border=True):
            st.markdown("### 🏅 Desafio da semana")
            st.markdown("**Complete 10 km**")
            st.progress(0.6)
            st.caption("Exemplo de progresso: 6 km de 10 km.")
    with c2:
        with st.container(border=True):
            st.markdown("### 🤝 Encontre companhia")
            st.write("A proposta é permitir compartilhar desafios e experiências com outros corredores.")
            st.caption("Funcionalidade conceitual; sem usuários reais conectados.")
    st.markdown("### Sugestões da comunidade")
    st.write("• Compartilhar percursos favoritos")
    st.write("• Criar desafios entre amigos")
    st.write("• Publicar resultados e conquistas")

st.markdown("---")
st.caption("FORTALRUN • Projeto de Extensão • Protótipo acadêmico não comercial")
